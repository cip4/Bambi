#!/bin/sh
java org/cip4/bambi/Executor # 
